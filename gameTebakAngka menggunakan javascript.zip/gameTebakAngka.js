alert("Game tebak huruf dan angka  \n Kesempatan anda sebanyak 3x");

		var angkaAcak 	=  Math.floor(Math.random() * 10 + 1);



//mempunyai 3 kesempatan
var kesempatan = 3;

while(kesempatan > 0 ) {
	//user memasukkan angka
	var angkaUser = prompt(" Masukkan Angka ");

	//hasil 
	var hasil = '';
	//jika benar
	if (angkaUser  == angkaAcak) {
		alert(" Angka yang anda masukkan benar! Angka yang dicari adalah " + angkaAcak);
		break;
	}else if (angkaUser < angkaAcak) {
		alert(" Angka yang anda masukkan terlalu rendah! ");
		
	}else if (angkaUser > angkaAcak) {
		alert("Angka yang anda masukkan terlalu tinggi!");

	}else {
		alert("Angka yang anda masukkan salah!");
	}

	//kesempatak berkurang setiap salah
	kesempatan--;

	//jika kesempatan 0 maka outputnya berbeda 
	if (kesempatan == 0 ) {
		alert( hasil + "kesempatan kamu telah habis!");
		alert("Angka yang benar adalah" + angkaUser);
	}else {
		alert(hasil + " \nkesempatan anda bermain  tinggal " + kesempatan + " x ");
	}
}
alert('terima kasih sudah bermain');

